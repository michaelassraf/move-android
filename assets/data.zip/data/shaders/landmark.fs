#ifdef GL_ES
precision mediump float;
#endif

varying vec4 v_color;
varying vec2 v_texcoord0;
uniform sampler2D u_sampler0;

void main (void)
{
	vec4 texcolor = texture2D (u_sampler0, v_texcoord0);
	if(texcolor.a < 0.5)
		discard;
	gl_FragColor = texcolor * v_color;
}
