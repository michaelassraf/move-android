#ifdef GL_ES
precision mediump float;
#endif

uniform vec4 u_color;
varying vec2 v_texcoord0;
uniform sampler2D u_sampler0;

void main (void)
{
	vec4 texcolor = texture2D (u_sampler0, v_texcoord0);
	gl_FragColor = u_color;
	gl_FragColor.a = texcolor.a;
}
