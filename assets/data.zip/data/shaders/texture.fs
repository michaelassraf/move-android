#ifdef GL_ES
precision mediump float;
#endif

uniform sampler2D u_sampler0;
varying vec2 v_texcoord0;

void main (void)
{
	vec4 texcolor = texture2D(u_sampler0, v_texcoord0);

	if (texcolor.a > 0.0)
		gl_FragColor = texcolor;
	else
		discard;
}
