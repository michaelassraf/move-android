#ifdef GL_ES
precision mediump float;
#endif

varying vec2 v_texcoord0;
uniform sampler2D u_sampler0;

void main (void)
{
	gl_FragColor = texture2D (u_sampler0, v_texcoord0);
}
